def quicktext():
    print('Hello, welcome to QuickSample package.')